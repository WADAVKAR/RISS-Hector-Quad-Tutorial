# kalman-tracking

![Trajectory tracking](/trajectories.svg)
